package com.salman.springbootCourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
